## ---- pkgs, echo=FALSE, message=FALSE------------------------------------
library(knitr)
opts_chunk$set(echo=FALSE, message=FALSE, warning=FALSE,
  fig.width=5, fig.height=3, fig.pos='H')
library(ioalbmse)

## ---- data---------------------------------------------------------------
data(oms)

