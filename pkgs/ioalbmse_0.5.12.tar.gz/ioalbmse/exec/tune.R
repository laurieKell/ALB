# tune.R - DESC
# /tune.R

# Copyright European Union, 2017
# Author: Iago Mosqueira (EC JRC) <iago.mosqueira@ec.europa.eu>
#
# Distributed under the terms of the European Union Public Licence (EUPL) V.1.1.


# TUNE 1: P(B > B_MSY) = 0.5, 20 y mean

# TUNE 2: P(kobe=green) = 0.75, 20 y mean

