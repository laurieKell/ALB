# FLBiol.R - DESC
# FLBiol.R

# Copyright 2015 Iago Mosqueira. Distributed under the GPL 2.
# Maintainer: Iago Mosqueira, JRC
# Soundtrack:
# Notes:

# CREATE objects

# COERCE objects

