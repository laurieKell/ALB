#' Updating FLash
#'
#' Some guff on FLR and Rcpp and CppAD
#' Very important
#'
#' @import FLCore
#' @docType package
#' @name FLasher
#' @aliases FLasher, FLasher-package
#' @useDynLib FLasher
NULL
