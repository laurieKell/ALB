/* 
 * Copyright 2014 FLR Team. Distributed under the GPL 2 or later
 * Maintainer: Finlay Scott, JRC
 */
// @// \[\[Rcpp::export]]@//'\@rdname FLFishery-cpp-tests\r// \[\[Rcpp::export]]@g 
#include "../../inst/include/FLFishery.h"

/*-------------------------------------------------------*/
// double

//'@title Tests for CPP implementation of FLFishery and FLFisheries
//
//' Shit tonnes of them!
//'
//'@param flf_sexp something
//'@param flf something
//'@param flf1 something
//'@param catches something
//'@param quant something
//'@param year something
//'@param unit something
//'@param season something
//'@param area something
//'@param iter something
//'@param value something
//'@param indices_min something
//'@param indices_max something
//'@param element something
//'@param fishery something
//'@param flfs_sexp1 something
//'@param flfs something
//'@param flfs1 something
//'@param indices something
//'@param fisheries something
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
void test_FLFishery_empty_constructor(){
    FLFishery flf;
    return;
}

//'@rdname FLFishery-cpp-tests
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
int test_simple_FLFishery_sexp_constructor(SEXP flf_sexp){
    FLFishery flf(flf_sexp);
	return 0;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFishery test_FLFishery_sexp_constructor(SEXP flf_sexp){
	FLFishery flf(flf_sexp);
	return flf;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFishery test_FLFishery_as_wrap(FLFishery flf){
	return flf;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFishery test_FLFishery_copy_constructor(FLFishery flf1){
	FLFishery flf2(flf1); // uses copy constructor
    return flf2;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFishery test_FLFishery_assignment_operator(FLFishery flf1){
	FLFishery flf2;
    flf2 = flf1; 
    return flf2;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFishery_const_catches_get_accessors(const FLFishery flf, int catches, int quant, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(13);
    // members
    out[0] = flf(catches).landings_n()(quant, year, unit, season, area, iter);
    out[1] = flf(catches).discards_n()(quant, year, unit, season, area, iter);
    out[2] = flf(catches).landings_wt()(quant, year, unit, season, area, iter);
    out[3] = flf(catches).discards_wt()(quant, year, unit, season, area, iter);
    out[4] = flf(catches).catch_sel()(quant, year, unit, season, area, iter);
    out[5] = flf(catches).price()(quant, year, unit, season, area, iter);
    // derived members
    out[6] = flf(catches).catches()(1, year, unit, season, area, iter);
    out[7] = flf(catches).catch_n()(quant, year, unit, season, area, iter);
    out[8] = flf(catches).landings()(1, year, unit, season, area, iter);
    out[9] = flf(catches).discards()(1, year, unit, season, area, iter);
    out[10] = flf(catches).landings_sel()(quant, year, unit, season, area, iter);
    out[11] = flf(catches).discards_sel()(quant, year, unit, season, area, iter);
    out[12] = flf(catches).discards_ratio()(quant, year, unit, season, area, iter);
    //out[6] = flc.catch_q()(quant, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFishery_catches_get_accessors(FLFishery flf, int catches, int quant, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(13);
    // members
    out[0] = flf(catches).landings_n()(quant, year, unit, season, area, iter);
    out[1] = flf(catches).discards_n()(quant, year, unit, season, area, iter);
    out[2] = flf(catches).landings_wt()(quant, year, unit, season, area, iter);
    out[3] = flf(catches).discards_wt()(quant, year, unit, season, area, iter);
    out[4] = flf(catches).catch_sel()(quant, year, unit, season, area, iter);
    out[5] = flf(catches).price()(quant, year, unit, season, area, iter);
    // derived members
    out[6] = flf(catches).catches()(1, year, unit, season, area, iter);
    out[7] = flf(catches).catch_n()(quant, year, unit, season, area, iter);
    out[8] = flf(catches).landings()(1, year, unit, season, area, iter);
    out[9] = flf(catches).discards()(1, year, unit, season, area, iter);
    out[10] = flf(catches).landings_sel()(quant, year, unit, season, area, iter);
    out[11] = flf(catches).discards_sel()(quant, year, unit, season, area, iter);
    out[12] = flf(catches).discards_ratio()(quant, year, unit, season, area, iter);
    //out[6] = flc.catch_q()(quant, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFishery_const_economics_get_accessors(const FLFishery flf, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(3);
    out[0] = flf.effort()(1, year, unit, season, area, iter);
    out[1] = flf.vcost()(1, year, unit, season, area, iter);
    out[2] = flf.fcost()(1, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
double test_FLFishery_const_get_hperiod(const FLFishery flf, int quant, int year, int unit, int season, int area, int iter){
    return flf.hperiod()(quant, year, unit, season, area, iter);
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
double test_FLFishery_get_hperiod(FLFishery flf, int quant, int year, int unit, int season, int area, int iter){
    return flf.hperiod()(quant, year, unit, season, area, iter);
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLQuant test_FLFishery_set_hperiod(FLFishery flf, int quant, int year, int unit, int season, int area, int iter, double value){
    flf.hperiod()(quant, year, unit, season, area, iter) = value;
    return flf.hperiod();
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLQuant test_FLFishery_get_effort_subset(const FLFishery flf, const std::vector<unsigned int> indices_min, const std::vector<unsigned int> indices_max){
    return flf.effort(indices_min, indices_max);
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLQuant test_FLFishery_get_effort(const FLFishery flf){
    return flf.effort();
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFishery_economics_get_accessors(FLFishery flf, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(3);
    out[0] = flf.effort()(1, year, unit, season, area, iter);
    out[1] = flf.vcost()(1, year, unit, season, area, iter);
    out[2] = flf.fcost()(1, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFishery test_FLFishery_set_accessors(FLFishery flf, int catches, int quant, int year, int unit, int season, int area, int iter, double value){
    // catch members
    flf(catches).landings_n()(quant, year, unit, season, area, iter) = value;
    flf(catches).discards_n()(quant, year, unit, season, area, iter) = value;
    flf(catches).landings_wt()(quant, year, unit, season, area, iter) = value;
    flf(catches).discards_wt()(quant, year, unit, season, area, iter) = value;
    flf(catches).catch_sel()(quant, year, unit, season, area, iter) = value;
    flf(catches).price()(quant, year, unit, season, area, iter) = value;
    // economics
    flf.effort()(1, year, unit, season, area, iter) = value;
    flf.vcost()(1, year, unit, season, area, iter) = value;
    flf.fcost()(1, year, unit, season, area, iter) = value;
    return flf;
}



//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFishery_copy_constructor2(FLFishery flf1, int element, int quant, int year, int unit, int season, int area, int iter, double value){
	FLFishery flf2(flf1); // uses copy constructor
	flf2(element).landings_n()(quant,year,unit,season,area,iter) = value;
	return Rcpp::List::create(Rcpp::Named("flf1", flf1),
				Rcpp::Named("flf2",flf2));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFishery_assignment_operator2(FLFishery flf1, int element, int quant, int year, int unit, int season, int area, int iter, double value){
	FLFishery flf2;
    flf2 = flf1; // uses assignment operator;
	flf2(element).landings_n()(quant,year,unit,season,area,iter) = value;
	return Rcpp::List::create(Rcpp::Named("flf1", flf1),
				Rcpp::Named("flf2",flf2));
}

/*-------------------------------------------------------*/
// adouble

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
void test_FLFisheryAD_empty_constructor(){
    FLFisheryAD flf;
    return;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
int test_simple_FLFisheryAD_sexp_constructor(SEXP flf_sexp){
    FLFisheryAD flf(flf_sexp);
	return 0;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_sexp_constructor(SEXP flf_sexp){
	FLFisheryAD flf(flf_sexp);
	return flf;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_as_wrap(FLFisheryAD flf){
	return flf;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_copy_constructor(FLFisheryAD flf1){
	FLFisheryAD flf2(flf1); // uses copy constructor
    return flf2;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_assignment_operator(FLFisheryAD flf1){
	FLFisheryAD flf2;
    flf2 = flf1; 
    return flf2;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFisheryAD_const_catches_get_accessors(const FLFisheryAD flf, int catches, int quant, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(13);
    // members
    out[0] = Value(flf(catches).landings_n()(quant, year, unit, season, area, iter));
    out[1] = Value(flf(catches).discards_n()(quant, year, unit, season, area, iter));
    out[2] = flf(catches).landings_wt()(quant, year, unit, season, area, iter);
    out[3] = flf(catches).discards_wt()(quant, year, unit, season, area, iter);
    out[4] = flf(catches).catch_sel()(quant, year, unit, season, area, iter);
    out[5] = flf(catches).price()(quant, year, unit, season, area, iter);
    // derived members
    out[6] = Value(flf(catches).catches()(1, year, unit, season, area, iter));
    out[7] = Value(flf(catches).catch_n()(quant, year, unit, season, area, iter));
    out[8] = Value(flf(catches).landings()(1, year, unit, season, area, iter));
    out[9] = Value(flf(catches).discards()(1, year, unit, season, area, iter));
    out[10] = Value(flf(catches).landings_sel()(quant, year, unit, season, area, iter));
    out[11] = Value(flf(catches).discards_sel()(quant, year, unit, season, area, iter));
    out[12] = Value(flf(catches).discards_ratio()(quant, year, unit, season, area, iter));
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFisheryAD_catches_get_accessors(FLFisheryAD flf, int catches, int quant, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(13);
    // members
    out[0] = Value(flf(catches).landings_n()(quant, year, unit, season, area, iter));
    out[1] = Value(flf(catches).discards_n()(quant, year, unit, season, area, iter));
    out[2] = flf(catches).landings_wt()(quant, year, unit, season, area, iter);
    out[3] = flf(catches).discards_wt()(quant, year, unit, season, area, iter);
    out[4] = flf(catches).catch_sel()(quant, year, unit, season, area, iter);
    out[5] = flf(catches).price()(quant, year, unit, season, area, iter);
    // derived members
    out[6] = Value(flf(catches).catches()(1, year, unit, season, area, iter));
    out[7] = Value(flf(catches).catch_n()(quant, year, unit, season, area, iter));
    out[8] = Value(flf(catches).landings()(1, year, unit, season, area, iter));
    out[9] = Value(flf(catches).discards()(1, year, unit, season, area, iter));
    out[10] = Value(flf(catches).landings_sel()(quant, year, unit, season, area, iter));
    out[11] = Value(flf(catches).discards_sel()(quant, year, unit, season, area, iter));
    out[12] = Value(flf(catches).discards_ratio()(quant, year, unit, season, area, iter));
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFisheryAD_const_economics_get_accessors(const FLFisheryAD flf, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(3);
    out[0] = Value(flf.effort()(1, year, unit, season, area, iter));
    out[1] = flf.vcost()(1, year, unit, season, area, iter);
    out[2] = flf.fcost()(1, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::NumericVector test_FLFisheryAD_economics_get_accessors(FLFisheryAD flf, int year, int unit, int season, int area, int iter){
    Rcpp::NumericVector out(3);
    out[0] = Value(flf.effort()(1, year, unit, season, area, iter));
    out[1] = flf.vcost()(1, year, unit, season, area, iter);
    out[2] = flf.fcost()(1, year, unit, season, area, iter);
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_set_accessors(FLFisheryAD flf, int catches, int quant, int year, int unit, int season, int area, int iter, double value){
    adouble ad_value = value;
    // catch members
    flf(catches).landings_n()(quant, year, unit, season, area, iter) = ad_value;
    flf(catches).discards_n()(quant, year, unit, season, area, iter) = ad_value;
    flf(catches).landings_wt()(quant, year, unit, season, area, iter) = value;
    flf(catches).discards_wt()(quant, year, unit, season, area, iter) = value;
    flf(catches).catch_sel()(quant, year, unit, season, area, iter) = value;
    flf(catches).price()(quant, year, unit, season, area, iter) = value;
    // economics
    flf.effort()(1, year, unit, season, area, iter) = value;
    flf.vcost()(1, year, unit, season, area, iter) = value;
    flf.fcost()(1, year, unit, season, area, iter) = value;
    return flf;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheryAD_copy_constructor2(FLFisheryAD flf1, int element, int quant, int year, int unit, int season, int area, int iter, double value){
    adouble ad_value = value;
	FLFisheryAD flf2(flf1); // uses copy constructor
	flf2(element).landings_n()(quant,year,unit,season,area,iter) = ad_value;
	return Rcpp::List::create(Rcpp::Named("flf1", flf1),
				Rcpp::Named("flf2",flf2));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheryAD_assignment_operator2(FLFisheryAD flf1, int element, int quant, int year, int unit, int season, int area, int iter, double value){
    adouble ad_value = value;
	FLFisheryAD flf2;
    flf2 = flf1; // uses assignment operator;
	flf2(element).landings_n()(quant,year,unit,season,area,iter) = ad_value;
	return Rcpp::List::create(Rcpp::Named("flf1", flf1),
				Rcpp::Named("flf2",flf2));
}

// iterators
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheryAD_const_iterator(const FLFisheryAD fishery){
    Rcpp::List out;
    for (const auto flcatch : fishery){
        out.push_back(flcatch.landings_n());
    }
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheryAD test_FLFisheryAD_iterator(FLFisheryAD fishery, int quant, int year, int unit, int season, int area, int iter, double value){
    for (auto& flcatch : fishery){
        flcatch.landings_n()(quant, year, unit, season, area, iter) = value;
    }
    return fishery;
}

//---------------------------------------------------------------------------------------
// FLFisheries - double

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_sexp_constructor(SEXP flfs_sexp1){
	FLFisheries flfs(flfs_sexp1);
	return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_as_wrap(FLFisheries flfs){
    return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
int test_FLFisheries_get_nfisheries(FLFisheries flfs){
    int length = flfs.get_nfisheries();
	return length;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_copy_constructor(FLFisheries flfs){
    FLFisheries out(flfs);
    return out;
}

// Checking that a deep copy has been made
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_copy_constructor2(FLFisheries flfs1, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheries flfs2(flfs1); // Copy
    flfs2(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
	return Rcpp::List::create(Rcpp::Named("flfs1", flfs1),
                            Rcpp::Named("flfs2",flfs2));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_assignment_operator(FLFisheries flfs){
    FLFisheries out;
    out = flfs;
    return out;
}

// Checking that a deep copy has been made
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_assignment_operator2(FLFisheries flfs1, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheries flfs2; 
    flfs2 = flfs1;
    flfs2(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
	return Rcpp::List::create(Rcpp::Named("flfs1", flfs1),
                            Rcpp::Named("flfs2",flfs2));
}

// Const get everything
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_const_get_single(const FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFishery flf = flfs(fishery);
    FLCatch flc = flfs(fishery)(catches);
    FLQuant landings_n = flfs(fishery)(catches).landings_n();
    double value = flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]);
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

// get everything
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_get_single(FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFishery flf = flfs(fishery);
    FLCatch flc = flfs(fishery)(catches);
    FLQuant landings_n = flfs(fishery)(catches).landings_n();
    //double value = flfs(fishery)(catches).landings_n()(indices[0],indices[1],indices[2],indices[3],indices[4],indices[5]);
    double value = flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]);
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_const_get_double(const FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFishery flf = flfs(fishery);
    FLCatch flc = flfs(fishery, catches);
    FLQuant landings_n = flfs(fishery, catches).landings_n();
    double value = flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]);
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheries_get_double(FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFishery flf = flfs(fishery);
    FLCatch flc = flfs(fishery, catches);
    FLQuant landings_n = flfs(fishery, catches).landings_n();
    double value = flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]);
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_set_single(FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
    return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheries test_FLFisheries_set_double(FLFisheries flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
    return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLQuant test_FLFishery_revenue(const FLFishery flf){
    return flf.revenue();
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLQuant test_FLFishery_revenue_subset(const FLFishery flf, const std::vector<unsigned int> indices_min, const std::vector<unsigned int> indices_max){
    return flf.revenue(indices_min, indices_max);
}

//---------------------------------------------------------------------------
// FLFisheries - adouble

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_sexp_constructor(SEXP flfs_sexp1){
	FLFisheriesAD flfs(flfs_sexp1);
	return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_as_wrap(FLFisheriesAD flfs){
    return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
int test_FLFisheriesAD_get_nfisheries(FLFisheriesAD flfs){
    int length = flfs.get_nfisheries();
	return length;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_copy_constructor(FLFisheriesAD flfs){
    FLFisheriesAD out(flfs);
    return out;
}

// Checking that a deep copy has been made
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_copy_constructor2(FLFisheriesAD flfs1, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    adouble ad_value = value;
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheriesAD flfs2(flfs1); // Copy
    flfs2(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = ad_value;
	return Rcpp::List::create(Rcpp::Named("flfs1", flfs1),
                            Rcpp::Named("flfs2",flfs2));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_assignment_operator(FLFisheriesAD flfs){
    FLFisheriesAD out;
    out = flfs;
    return out;
}

// Checking that a deep copy has been made
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_assignment_operator2(FLFisheriesAD flfs1, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    adouble ad_value = value;
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheriesAD flfs2; 
    flfs2 = flfs1;
    flfs2(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = ad_value;
	return Rcpp::List::create(Rcpp::Named("flfs1", flfs1),
                            Rcpp::Named("flfs2",flfs2));
}

// Const get everything
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_const_get_single(const FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheryAD flf = flfs(fishery);
    FLCatchAD flc = flfs(fishery)(catches);
    FLQuantAD landings_n = flfs(fishery)(catches).landings_n();
    //double value = flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]).value();
    double value = Value(flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]));
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

// get everything
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_get_single(FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheryAD flf = flfs(fishery);
    FLCatchAD flc = flfs(fishery)(catches);
    FLQuantAD landings_n = flfs(fishery)(catches).landings_n();
    //double value = flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]).value();
    double value = Value(flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]));
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_const_get_double(const FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheryAD flf = flfs(fishery);
    FLCatchAD flc = flfs(fishery, catches);
    FLQuantAD landings_n = flfs(fishery, catches).landings_n();
    //double value = flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]).value();
    double value = Value(flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]));
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_get_double(FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    FLFisheryAD flf = flfs(fishery);
    FLCatchAD flc = flfs(fishery, catches);
    FLQuantAD landings_n = flfs(fishery, catches).landings_n();
    //double value = flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]).value();
    double value = Value(flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]));
    return Rcpp::List::create(Rcpp::Named("flf",flf),
            Rcpp::Named("flc", flc),
            Rcpp::Named("landings_n", landings_n),
            Rcpp::Named("value", value));
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_set_single(FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    flfs(fishery)(catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
    return flfs;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_set_double(FLFisheriesAD flfs, const int fishery, const int catches, const Rcpp::IntegerVector indices, double value){
    std::vector<int> std_indices = Rcpp::as<std::vector<int> > (indices);
    flfs(fishery, catches).landings_n()(std_indices[0],std_indices[1],std_indices[2],std_indices[3],std_indices[4],std_indices[5]) = value;
    return flfs;
}

// iterators
//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
Rcpp::List test_FLFisheriesAD_const_iterator(const FLFisheriesAD fisheries){
    Rcpp::List out;
    for (const auto fishery : fisheries){
        out.push_back(fishery.effort());
    }
    return out;
}

//'@rdname FLFishery-cpp-tests
// [[Rcpp::export]]
FLFisheriesAD test_FLFisheriesAD_iterator(FLFisheriesAD fisheries, double value){
    for (auto& fishery : fisheries){
        fishery.effort()(1, 1, 1, 1, 1, 1) = value;
    }
    return fisheries;
}

